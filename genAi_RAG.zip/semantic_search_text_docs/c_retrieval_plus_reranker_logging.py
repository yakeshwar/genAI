import os
from dotenv import load_dotenv
from pydantic_ai.models.groq import GroqModel
from pydantic_ai import Agent
from langchain_community.vectorstores import FAISS
from langchain_community.cross_encoders import HuggingFaceCrossEncoder
import logfire
#retriever
from langchain.retrievers import ContextualCompressionRetriever
from langchain_huggingface import HuggingFaceEmbeddings
from langchain.retrievers.document_compressors import CrossEncoderReranker

load_dotenv(override=True)
logfire.configure(token=os.getenv("LOGFIRE_TOKEN"))
logfire.instrument_openai()

#create a model

embeddings_model = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-mpnet-base-v2",
    encode_kwargs={"normalize_embeddings": True},
    model_kwargs={"token": os.getenv("HUGGING_FACE_TOKEN")},
)

system_promopt="""
    You are a log analyst. Analyze the following system logs and:
    1. Detect any meaningful sequences or events.
    2. Group related log lines if they belong to the same process or error.
    3. Provide a summarized and ordered interpretation of events.
"""

rag_agent = Agent(
    model=GroqModel(
        model_name=os.getenv("GROQ_CHAT_MODEL"),
        api_key=os.getenv("GROQ_API_KEY")
    ),
    system_prompt=system_promopt,
)


#load the vector db
vector_db_dir = os.path.expanduser(
    "./data/semantic_search/index/faiss2"
)

#get vector_db

vector_db = FAISS.load_local(
    folder_path=vector_db_dir,
    embeddings=embeddings_model,
    allow_dangerous_deserialization=True
)

def build_context(vector_db: FAISS, query: str, top_k: int):
    base_retriver = vector_db.as_retriever(search_kwargs={"k": top_k})
    hits = base_retriver.invoke(query)
    res = "\n".join([hit.page_content for hit in hits])
    return query + "\n<context>\n"+res+"\n</context>"

rerank_model = HuggingFaceCrossEncoder(
    model_name=os.getenv("HF_RERANKING_MODEL"),
)

while True:
    print("Enter your Query\n")
    query = input()
    
    if query == "q":
        break
    
    queryWithContext = build_context(vector_db=vector_db, query=query,top_k=5)
    
    #Ask the model to provide the Output based on the RAG(Query + Vector DB similar Entries)
    result=rag_agent.run_sync(queryWithContext)
    print("\nQuery:", query)
    print("\nAnswer:", result.data)