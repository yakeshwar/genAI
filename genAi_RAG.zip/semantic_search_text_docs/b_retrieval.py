import os
from dotenv import load_dotenv
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS

embeddings_model = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-mpnet-base-v2",
    encode_kwargs={"normalize_embeddings": True},
    model_kwargs={"token": os.getenv("HUGGING_FACE_TOKEN")},
)

#load the vector database
vector_db_dir = os.path.expanduser(
    "./data/semantic_search/index/faiss2"
)

vector_db = FAISS.load_local(
    folder_path=vector_db_dir,
    embeddings=embeddings_model,
    allow_dangerous_deserialization=True,
)

#Query sentences
queries = [
    "when the shutdown event happend?",
    "what is the timestamp of ups existing?",
    "when shutdown started?"
    "when UPS manager Exited?"
]

while True:
    print("\nProvide your Query: \n")
    query = input()

    if query.lower() == 'q':
        break

    #for query in queries:
    base_retriever = vector_db.as_retriever(search_kwargs={"k": 3})
    hits = base_retriever.invoke(query)

    print("\nQuery:", query)
    print("Top 3 most similar chunks in corpus/knowledge base:")

    for hit in hits:
        print(hit.page_content, f"\nSource:{hit.metadata.get("source")}")
        print()