import os
from dotenv import load_dotenv
from pydantic_ai.models.groq import GroqModel
from pydantic_ai import Agent
from langchain_community.vectorstores import FAISS
from langchain_community.cross_encoders import HuggingFaceCrossEncoder

#retriever
from langchain.retrievers import ContextualCompressionRetriever
from langchain_huggingface import HuggingFaceEmbeddings
from langchain.retrievers.document_compressors import CrossEncoderReranker

load_dotenv(override=True)

#create a model 

embeddings_model = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-mpnet-base-v2",
    encode_kwargs={"normalize_embeddings": True},
    model_kwargs={"token": os.getenv("HUGGING_FACE_TOKEN")},
)

system_prompt = """
You are a helpful and knowledgeable assistant for ups_manager and system_monitor logs .

Follow these guidelines:
- ALWAYS search the knowledge base that is provided in the context between <context> </context> tags to answer user questions. 
- Generate answer based ONLY on the information retrieved from the knowledge base.
- If information is not found in the knowledge base, politely acknowledge this.
"""

rag_agent = Agent(
    model=GroqModel(
        model_name=os.getenv("GROQ_CHAT_MODEL"), api_key=os.getenv("GROQ_API_KEY")
    ),
    system_prompt=system_prompt,
)

def build_context(vector_db: FAISS, query: str, top_k: int):
    base_retriever = vector_db.as_retriever(search_kwargs={"k": top_k})
    hits = base_retriever.invoke(query)
    res = "\n".join([hit.page_content for hit in hits])
    return query + "\n<context>\n" + res + "\n</context>"

#load the vector db
vector_db_dir = os.path.expanduser(
    "./data/semantic_search/index/faiss2"
)

#get vector_db

vector_db = FAISS.load_local(
    folder_path=vector_db_dir,
    embeddings=embeddings_model,
    allow_dangerous_deserialization=True
)

#Query sentences
queries = [
    "when is the Timestamp of Entering shutdown?" 
    "What is the Timestamp of Exiting shutdown?",
    "what is the Timestamp of Command received in ups manager ?",
    "What is the Timestamp of UPS Exiting ?",
    "Display logs which starts with UPSDEBUG?"
]

#retriver + reranker

rerank_model = HuggingFaceCrossEncoder(
    model_name=os.getenv("HF_RERANKING_MODEL"),
)


#for query in queries:
#    base_retriver=vector_db.as_retriever( search_kwargs={"k": 10} )
#    compressor = CrossEncoderReranker(model=rerank_model,top_n=3)
#    compressor_retriver=ContextualCompressionRetriever(base_compressor=compressor,base_retriever=base_retriver)

#    hits = compressor_retriver.invoke(query)
#    print("\nQuery:", query)
#    print("Top 2 most similar chunks in corpus/knowledge base:")
    #print(hits)

#    for hit in hits:
#        print(hit.page_content,
#              f"\nSoruce:{hit.metadata.get("source")}",
#              )
#        print()

#for query in queries:
#    queryWithContext = build_context(vector_db=vector_db, query=query, top_k=2)
#    result = rag_agent.run_sync(queryWithContext)
#    print("\nQuery:", query)
#    print("\nAnswer:", result.data)

while True:
    print("Enter your Query\n")
    query = input()
    
    if query == "q":
        break
    
    queryWithContext = build_context(vector_db=vector_db, query=query,top_k=2)
    result=rag_agent.run_sync(queryWithContext)
    print("\nQuery:", query)
    print("\nAnswer:", result.data)