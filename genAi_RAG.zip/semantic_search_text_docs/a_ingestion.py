from pathlib import Path
import time
import os
from dotenv import load_dotenv
from datetime import datetime
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_text_splitters import(
    CharacterTextSplitter,
    RecursiveCharacterTextSplitter,
)

from langchain_community.vectorstores.faiss import DistanceStrategy
from langchain_community.document_loaders import TextLoader

load_dotenv(override=True)

#read all text files , chunk them
kb_dir = os.path.expanduser(
    "./data/semantic_search/kb1"
)


def sort_log_file_using_timestamp(file_path)  -> str:
    from datetime import datetime

    output_path = "sorted_log_file.log"

    log_lines = []
    # Step 1: Read and parse each line
    with open(file_path, "r") as file:
        for line in file:
            try:
                timestamp_str = line.split(']')[0].strip('[')
                timestamp = datetime.strptime(timestamp_str, "%H:%M:%S.%f")
                log_lines.append((timestamp, line.strip()))
        
            except ValueError:
                continue  # Skip lines that don't match timestamp format

    # Step 2: Sort the lines by timestamp
    log_lines.sort(key=lambda x: x[0])

    # Step 3: Write to new file
    with open(output_path, "w+") as file:
        for _, log_line in log_lines:
            file.write(log_line + "\n")

    print(f"Sorted log written to {output_path}")
    return output_path

def read_logs_from_kb(kb_dir) -> str:

    log_dir = Path(kb_dir)
    output_path = "sorted_log_dup123.log"
    
    with open(output_path, "w+") as out:
        for log_file in log_dir.glob("*.log"):
            print(f"Processing {log_file.name}")
            with open(log_file, "r") as f:
                for line in f:
                    out.write(line if line.endswith("\n") else line + "\n")
    
    combined_file_name = sort_log_file_using_timestamp(output_path)
    
    return combined_file_name


text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=100,
    chunk_overlap=20,
    length_function=len,
)

documents = []

common_file = read_logs_from_kb(kb_dir)
loader= TextLoader(common_file)
documents.extend(loader.load_and_split(text_splitter))

# create embeddings for all the chunks and store them in vector database
embedding_model = HuggingFaceEmbeddings(
    model_name=os.getenv("HF_EMBEDDINGS_MODEL"),
    encode_kwargs={"normalize_embeddings": True},
    model_kwargs={"token": os.getenv("HUGGING_FACE_TOKEN")},
)

#create the vector DB

vector_db = FAISS.from_documents(
    documents=documents,
    embedding=embedding_model,
    distance_strategy=DistanceStrategy.EUCLIDEAN_DISTANCE,
)

vector_db_dir = os.path.expanduser(
    "./data/semantic_search/index/faiss2"
)

vector_db.save_local(folder_path=vector_db_dir)
print("vector db sucessfully created")